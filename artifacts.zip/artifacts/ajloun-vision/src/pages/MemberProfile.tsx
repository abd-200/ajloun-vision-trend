import { useGetMember, getGetMemberQueryKey, useGetMemberImpact, getGetMemberImpactQueryKey } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Award, Calendar, ArrowRight, Target, ShieldCheck } from "lucide-react";

export default function MemberProfile() {
  const params = useParams();
  const id = parseInt(params.id || "0");
  
  const { data: member, isLoading: memberLoading } = useGetMember(id, { 
    query: { enabled: !!id, queryKey: getGetMemberQueryKey(id) } 
  });
  
  const { data: impact, isLoading: impactLoading } = useGetMemberImpact(id, {
    query: { enabled: !!id, queryKey: getGetMemberImpactQueryKey(id) }
  });

  if (memberLoading) {
    return (
      <div className="container py-12 px-4 max-w-4xl">
        <Skeleton className="h-40 w-full rounded-2xl mb-12 relative">
          <Skeleton className="w-32 h-32 rounded-full absolute -bottom-16 right-8 border-4 border-background" />
        </Skeleton>
        <div className="mt-20">
          <Skeleton className="h-10 w-1/3 mb-4" />
          <Skeleton className="h-6 w-1/4 mb-8" />
          <Skeleton className="h-32 w-full mb-8" />
        </div>
      </div>
    );
  }

  if (!member) {
    return (
      <div className="container py-24 text-center">
        <h2 className="text-2xl font-bold mb-4">لم يتم العثور على العضو</h2>
        <Link href="/members" className="text-primary hover:underline">العودة لقائمة الأعضاء</Link>
      </div>
    );
  }

  const roleMap: Record<string, string> = {
    admin: "إدارة",
    coordinator: "منسق",
    member: "عضو نشط"
  };

  return (
    <div className="container py-12 px-4 max-w-4xl">
      <Link href="/members" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-6">
        <ArrowRight className="w-4 h-4 ml-2" /> العودة للأعضاء
      </Link>
      
      {/* Profile Header */}
      <div className="bg-card rounded-2xl border overflow-hidden mb-8">
        <div className="h-32 md:h-48 bg-primary/10 w-full relative">
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
        </div>
        <div className="px-6 md:px-10 pb-8 relative">
          <div className="flex flex-col md:flex-row md:items-end gap-6 -mt-16 md:-mt-20 mb-6 relative z-10">
            <Avatar className="w-32 h-32 md:w-40 md:h-40 border-4 border-background shadow-md">
              <AvatarImage src={member.avatarUrl || undefined} />
              <AvatarFallback className="text-4xl bg-muted text-muted-foreground">
                {member.fullNameAr.substring(0, 2)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 pb-2">
              <div className="flex flex-wrap items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold text-foreground">{member.fullNameAr}</h1>
                {member.isActive && <Badge variant="default" className="bg-green-600">نشط</Badge>}
              </div>
              <p className="text-lg text-muted-foreground font-medium">{roleMap[member.role] || member.role}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-muted-foreground">
            {member.location && (
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" />
                <span>{member.location}</span>
              </div>
            )}
            {member.joinedAt && (
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                <span>انضم في {new Date(member.joinedAt).toLocaleDateString('ar-JO')}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          {/* Bio */}
          {member.bioAr && (
            <Card className="border-none shadow-sm bg-muted/20">
              <CardHeader>
                <CardTitle className="text-xl">نبذة تعريفية</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                  {member.bioAr}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Impact Stats */}
          {!impactLoading && impact && (
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Target className="w-6 h-6 text-primary" />
                الأثر المجتمعي
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-card border rounded-xl p-4 text-center shadow-sm">
                  <div className="text-3xl font-bold text-accent mb-1">{impact.impactScore}</div>
                  <div className="text-xs text-muted-foreground">نقطة أثر</div>
                </div>
                <div className="bg-card border rounded-xl p-4 text-center shadow-sm">
                  <div className="text-3xl font-bold text-primary mb-1">{impact.initiativesJoined}</div>
                  <div className="text-xs text-muted-foreground">مبادرات شارك بها</div>
                </div>
                <div className="bg-card border rounded-xl p-4 text-center shadow-sm col-span-2 md:col-span-1">
                  <div className="text-3xl font-bold text-primary mb-1">{impact.initiativesLed}</div>
                  <div className="text-xs text-muted-foreground">مبادرات قادها</div>
                </div>
              </div>

              {impact.recentInitiatives && impact.recentInitiatives.length > 0 && (
                <div className="space-y-4 mt-8">
                  <h3 className="font-bold text-lg">أحدث المبادرات</h3>
                  <div className="space-y-3">
                    {impact.recentInitiatives.map(init => (
                      <Link key={init.id} href={`/initiatives/${init.id}`}>
                        <div className="flex items-center p-3 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer">
                          <div className="w-12 h-12 rounded bg-primary/10 flex items-center justify-center ml-4 shrink-0 overflow-hidden">
                            {init.imageUrl ? (
                              <img src={init.imageUrl} alt={init.titleAr} className="w-full h-full object-cover" />
                            ) : (
                              <Target className="w-5 h-5 text-primary" />
                            )}
                          </div>
                          <div>
                            <h4 className="font-medium text-sm line-clamp-1">{init.titleAr}</h4>
                            <p className="text-xs text-muted-foreground">{init.category}</p>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {!impactLoading && impact && impact.badges && impact.badges.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Award className="w-5 h-5 text-accent" />
                  الأوسمة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {impact.badges.map((badge, idx) => (
                    <Badge key={idx} variant="outline" className="bg-accent/10 text-accent border-accent/20 px-3 py-1.5 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      {badge}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
